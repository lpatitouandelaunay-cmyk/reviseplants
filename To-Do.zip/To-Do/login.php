<?php
session_start();

$admin_password = "1234"; // 🔐 CHANGE LE MOT DE PASSE

if (isset($_POST["password"])) {
    if ($_POST["password"] === $admin_password) {
        $_SESSION["admin"] = true;
        header("Location: index.php");
        exit;
    } else {
        $error = "Mot de passe incorrect.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Connexion Admin</title>
</head>
<body>
<h2>Connexion Admin</h2>

<form method="POST">
    <input type="password" name="password" placeholder="Mot de passe admin" required>
    <button type="submit">Se connecter</button>
</form>

<?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>

</body>
</html>
