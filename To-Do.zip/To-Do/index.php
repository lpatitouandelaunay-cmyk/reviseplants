<?php
session_start();

// Fichier de stockage
$dataFile = "tasks.json";

if (!file_exists($dataFile)) {
    file_put_contents($dataFile, json_encode([]));
}

$tasks = json_decode(file_get_contents($dataFile), true);

// Toggle case cochée (tout le monde peut)
if (isset($_GET["toggle"])) {
    $i = intval($_GET["toggle"]);
    $tasks[$i]["checked"] = !$tasks[$i]["checked"];
    file_put_contents($dataFile, json_encode($tasks));
    header("Location: index.php");
    exit;
}

// Ajouter (ADMIN SEULEMENT)
if (isset($_POST["new_task"]) && !empty($_POST["new_task"]) && isset($_SESSION["admin"])) {
    $tasks[] = ["text" => $_POST["new_task"], "checked" => false];
    file_put_contents($dataFile, json_encode($tasks));
    header("Location: index.php");
    exit;
}

// Supprimer (ADMIN SEULEMENT)
if (isset($_GET["delete"]) && isset($_SESSION["admin"])) {
    $i = intval($_GET["delete"]);
    unset($tasks[$i]);
    $tasks = array_values($tasks);
    file_put_contents($dataFile, json_encode($tasks));
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>To-Do Liste Publique</title>
</head>
<body>

<h2>To-Do Liste Publique</h2>

<?php if (!isset($_SESSION["admin"])): ?>
    <a href="login.php">Connexion Admin</a>
<?php else: ?>
    <p>Connecté en admin — <a href="logout.php">Déconnexion</a></p>
<?php endif; ?>

<hr>

<?php if (isset($_SESSION["admin"])): ?>
<form method="POST">
    <input type="text" name="new_task" placeholder="Nouvelle tâche..." required>
    <button type="submit">Ajouter</button>
</form>
<?php endif; ?>

<ul>
<?php foreach ($tasks as $i => $task): ?>
    <li>
        <a href="?toggle=<?=$i?>">
            <input type="checkbox" <?=$task["checked"] ? "checked" : ""?>>
            <?=htmlspecialchars($task["text"])?>
        </a>

        <?php if (isset($_SESSION["admin"])): ?>
            <a href="?delete=<?=$i?>" style="color:red;">[supprimer]</a>
        <?php endif; ?>
    </li>
<?php endforeach; ?>
</ul>

</body>
</html>
