<?php
session_start();

$servername = "localhost";  // normalement localhost sur OVH
$dbname = "nom_de_ta_base";
$dbuser = "ton_utilisateur";
$dbpass = "ton_mot_de_passe";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $dbuser, $dbpass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Erreur de connexion à la base : " . $e->getMessage());
}

// Définir l'admin
$ADMIN_ID = "admintitouan72";
$ADMIN_PW = "noeladmin72";
?>
