<?php
require "config.php";
if(!isset($_SESSION['user_id'])) { header("Location: index.php"); exit; }

// Récupérer tous les utilisateurs sauf soi
$stmt = $conn->prepare("SELECT id, username FROM users WHERE id != ?");
$stmt->execute([$_SESSION['user_id']]);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Si on choisit un utilisateur
$selected_user_id = $_GET['user_id'] ?? null;
$selected_user = null;
$gifts = [];

if($selected_user_id) {
    $stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->execute([$selected_user_id]);
    $selected_user = $stmt->fetch(PDO::FETCH_ASSOC);

    if($selected_user) {
        $stmt = $conn->prepare("SELECT * FROM lists WHERE user_id = ?");
        $stmt->execute([$selected_user_id]);
        $gifts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Voir une liste</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<h1>Voir la liste d'une personne</h1>

<form method="GET">
    <select name="user_id">
        <option value="">--Choisir une personne--</option>
        <?php foreach($users as $user): ?>
            <option value="<?php echo $user['id']; ?>" <?php if($selected_user_id == $user['id']) echo "selected"; ?>>
                <?php echo htmlspecialchars($user['username']); ?>
            </option>
        <?php endforeach; ?>
    </select>
    <button type="submit">Voir</button>
</form>

<?php if($selected_user): ?>
    <h2>Liste de <?php echo htmlspecialchars($selected_user['username']); ?></h2>
    <?php if(count($gifts) == 0) echo "<p>Cette liste est vide.</p>"; ?>
    <?php foreach($gifts as $gift): ?>
        <div class="giftItem">
            <strong><?php echo htmlspecialchars($gift['gift_name']); ?></strong><br>
            <?php if($gift['gift_details']) echo "<em>".htmlspecialchars($gift['gift_details'])."</em><br>"; ?>
            <?php if($gift['gift_link']) echo '<a href="'.htmlspecialchars($gift['gift_link']).'" target="_blank">Voir le lien</a>'; ?>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<p><a href="dashboard.php">Retour à ma liste</a></p>
</body>
</html>
