<?php
require "config.php";
if(!isset($_SESSION['is_admin'])) { header("Location: index.php"); exit; }

// Supprimer utilisateur
if(isset($_GET['delete_user'])) {
    $id = $_GET['delete_user'];
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: admin.php");
    exit;
}

// Supprimer cadeau
if(isset($_GET['delete_gift'])) {
    $id = $_GET['delete_gift'];
    $stmt = $conn->prepare("DELETE FROM lists WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: admin.php");
    exit;
}

// Supprimer proposition
if(isset($_GET['delete_proposal'])) {
    $id = $_GET['delete_proposal'];
    $stmt = $conn->prepare("DELETE FROM proposals WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: admin.php");
    exit;
}

// Récupérer tous les utilisateurs, cadeaux et propositions
$users = $conn->query("SELECT * FROM users")->fetchAll(PDO::FETCH_ASSOC);
$gifts = $conn->query("SELECT l.*, u.username FROM lists l JOIN users u ON l.user_id = u.id")->fetchAll(PDO::FETCH_ASSOC);
$proposals = $conn->query("SELECT p.*, u1.username as from_name, u2.username as to_name FROM proposals p JOIN users u1 ON p.from_user = u1.id JOIN users u2 ON p.to_user = u2.id")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Admin Panel</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<h1>Panneau Admin</h1>

<h2>Utilisateurs</h2>
<?php foreach($users as $user): ?>
    <div>
        <?php echo htmlspecialchars($user['username']); ?>
        <a href="?delete_user=<?php echo $user['id']; ?>" onclick="return confirm('Supprimer cet utilisateur ?')">Supprimer</a>
    </div>
<?php endforeach; ?>

<h2>Cadeaux</h2>
<?php foreach($gifts as $gift): ?>
    <div class="giftItem">
        <strong><?php echo htmlspecialchars($gift['gift_name']); ?></strong> (<?php echo htmlspecialchars($gift['username']); ?>)
        <a href="?delete_gift=<?php echo $gift['id']; ?>" onclick="return confirm('Supprimer ce cadeau ?')">Supprimer</a>
    </div>
<?php endforeach; ?>

<h2>Propositions d'idées</h2>
<?php foreach($proposals as $prop): ?>
    <div class="giftItem">
        <?php echo htmlspecialchars($prop['from_name']); ?> → <?php echo htmlspecialchars($prop['to_name']); ?><br>
        <?php echo htmlspecialchars($prop['idea']); ?><br>
        <a href="?delete_proposal=<?php echo $prop['id']; ?>" onclick="return confirm('Supprimer cette proposition ?')">Supprimer</a>
    </div>
<?php endforeach; ?>

<p><a href="index.php">Déconnexion Admin</a></p>
</body>
</html>
