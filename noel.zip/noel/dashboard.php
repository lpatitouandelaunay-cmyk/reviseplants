<?php
require "config.php";
if(!isset($_SESSION['user_id'])) { header("Location: index.php"); exit; }

$user_id = $_SESSION['user_id'];

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['gift_name'])) {
    $gift_name = trim($_POST['gift_name']);
    $gift_details = trim($_POST['gift_details']);
    $gift_link = trim($_POST['gift_link']);

    if($gift_name) {
        $stmt = $conn->prepare("INSERT INTO lists (user_id, gift_name, gift_details, gift_link) VALUES (?, ?, ?, ?)");
        $stmt->execute([$user_id, $gift_name, $gift_details, $gift_link]);
    }
}

// Récupérer cadeaux
$stmt = $conn->prepare("SELECT * FROM lists WHERE user_id = ?");
$stmt->execute([$user_id]);
$gifts = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Ma liste de Noël</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<h1>Liste de <?php echo htmlspecialchars($_SESSION['username']); ?></h1>

<h2>Ajouter un cadeau</h2>
<form method="POST">
    <input type="text" name="gift_name" placeholder="Nom du cadeau" required><br>
    <textarea name="gift_details" placeholder="Plus de détails"></textarea><br>
    <input type="text" name="gift_link" placeholder="Lien (Amazon…)"><br>
    <button type="submit">Ajouter</button>
</form>

<h2>Mes cadeaux</h2>
<?php foreach($gifts as $gift): ?>
    <div class="giftItem">
        <strong><?php echo htmlspecialchars($gift['gift_name']); ?></strong><br>
        <?php if($gift['gift_details']) echo "<em>".htmlspecialchars($gift['gift_details'])."</em><br>"; ?>
        <?php if($gift['gift_link']) echo '<a href="'.htmlspecialchars($gift['gift_link']).'" target="_blank">Voir le lien</a>'; ?>
    </div>
<?php endforeach; ?>

<p><a href="view_list.php">Voir la liste d'une autre personne</a></p>
<p><a href="propose_idea.php">Proposer une idée de cadeau</a></p>
<p><a href="index.php">Déconnexion</a></p>
</body>
</html>
