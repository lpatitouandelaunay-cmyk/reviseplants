<?php
require "config.php";
if(!isset($_SESSION['user_id'])) { header("Location: index.php"); exit; }

$user_id = $_SESSION['user_id'];

// Liste des autres utilisateurs
$stmt = $conn->prepare("SELECT id, username FROM users WHERE id != ?");
$stmt->execute([$user_id]);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $to_user = $_POST['to_user'];
    $idea = trim($_POST['idea']);
    if($to_user && $idea) {
        $stmt = $conn->prepare("INSERT INTO proposals (from_user, to_user, idea) VALUES (?, ?, ?)");
        $stmt->execute([$user_id, $to_user, $idea]);
        $success = "Idée envoyée !";
    } else {
        $error = "Remplis tous les champs.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Proposer une idée</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<h1>Proposer une idée de cadeau</h1>
<?php if(isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
<?php if(isset($success)) echo "<p style='color:green;'>$success</p>"; ?>

<form method="POST">
    <select name="to_user" required>
        <option value="">--Choisir une personne--</option>
        <?php foreach($users as $user): ?>
            <option value="<?php echo $user['id']; ?>"><?php echo htmlspecialchars($user['username']); ?></option>
        <?php endforeach; ?>
    </select><br>
    <textarea name="idea" placeholder="Ton idée de cadeau..." required></textarea><br>
    <button type="submit">Envoyer</button>
</form>

<p><a href="dashboard.php">Retour à ma liste</a></p>
</body>
</html>
