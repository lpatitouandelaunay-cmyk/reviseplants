<?php
require 'db.php';
$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
    $password = $_POST["password"];
    $password_confirm = $_POST["password_confirm"];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Email invalide.";
    } elseif ($password !== $password_confirm) {
        $message = "Les mots de passe ne correspondent pas.";
    } elseif (strlen($password) < 6) {
        $message = "Mot de passe trop court (minimum 6 caractères).";
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (email, password) VALUES (?, ?)";
        try {
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$email, $hash]);
            $message = "Compte créé avec succès ! <a href='login.php'>Connectez-vous</a>";
        } catch (Exception $e) {
            $message = "Erreur : cet email existe déjà.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Inscription</title>
<link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="container">
<h2>Créer un compte</h2>
<form method="POST">
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Mot de passe" required>
    <input type="password" name="password_confirm" placeholder="Confirmer le mot de passe" required>
    <button type="submit">S'inscrire</button>
</form>
<p class="message"><?= $message ?></p>
<p>Déjà inscrit ? <a href="login.php">Se connecter</a></p>
</div>
</body>
</html>
