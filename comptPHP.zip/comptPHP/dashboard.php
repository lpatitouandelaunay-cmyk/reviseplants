<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Dashboard</title>
<link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="container">
<h2>Bienvenue !</h2>
<p>Connecté en tant que : <?= htmlspecialchars($_SESSION["user_email"]) ?></p>
<p><a href="logout.php">Se déconnecter</a></p>
</div>
</body>
</html>
