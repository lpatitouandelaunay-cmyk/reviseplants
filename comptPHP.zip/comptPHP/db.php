<?php
// db.php pour waterborn.fr
$host = "mysql51-123.perso";    // remplace par ton serveur OVH réel
$dbname = "waterborn_db";       // remplace par le nom réel de ta base
$username = "user_waterborn";   // ton utilisateur MySQL
$password = "TonMotDePasse";    // mot de passe OVH

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die("Erreur de connexion à la base : " . $e->getMessage());
}
?>
