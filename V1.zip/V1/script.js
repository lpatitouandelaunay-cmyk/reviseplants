function nettoyerNomEspece(nom) {
  return nom.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, "_").toLowerCase();
}

function nettoyerNomGenre(nom) {
  // Supprime les accents
  let propre = nom.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  
  // Découpe en mots, majuscule sur la première lettre de chaque mot
  propre = propre.split(/\s+/).map(mot => mot.charAt(0).toUpperCase() + mot.slice(1).toLowerCase()).join("_");
  
  return propre;
}

let plantes = [];
let selectedPlantes = [];
let questions = [];
let indexQuestion = 0;
let score = 0;
let erreurs = [];

// 🔹 Charger la liste des plantes
async function chargerPlantes() {
  try {
    const res = await fetch("./data/liste plante.txt");
    if (!res.ok) throw new Error("Fichier 'liste plante.txt' introuvable");
    const texte = await res.text();
    const lignes = texte.split("\n").map(l => l.trim()).filter(Boolean);
    let genreActuel = "";
    plantes = [];

    lignes.forEach(ligne => {
      if (ligne.endsWith(":")) {
        genreActuel = ligne.replace(":", "").trim();
      } else if (genreActuel) {
        plantes.push({
          genre: genreActuel,
          espece: ligne,
          image: `./images/${nettoyerNomGenre(genreActuel)}_${nettoyerNomEspece(ligne)}.jpg`
        });
      }
    });

    remplirGenres();
  } catch (err) {
    alert("❌ Erreur : " + err.message);
  }
}

// 🔹 Crée les menus
function remplirGenres() {
  const genres = [...new Set(plantes.map(p => p.genre))];
  const genreList = document.getElementById("genre-list");
  genreList.innerHTML = "";

  genres.forEach(genre => {
    const li = document.createElement("li");
    li.textContent = genre;
    li.addEventListener("click", () => {
      const duGenre = plantes.filter(p => p.genre === genre);
      duGenre.forEach(p => {
        if (!selectedPlantes.some(sp => sp.genre === p.genre && sp.espece === p.espece)) {
          selectedPlantes.push(p);
        }
      });
      afficherSelection();
    });
    genreList.appendChild(li);
  });

  const selectEspece = document.getElementById("select-espece");
  selectEspece.innerHTML = '<option value="">-- Choisir une espèce --</option>';
  plantes.forEach(p => {
    const opt = document.createElement("option");
    opt.value = `${p.genre}|${p.espece}`;
    opt.textContent = `${p.genre} ${p.espece}`;
    selectEspece.appendChild(opt);
  });

  selectEspece.addEventListener("change", ajouterPlanteAuto);
  selectEspece.addEventListener("keypress", e => {
    if (e.key === "Enter") ajouterPlanteAuto();
  });

  document.getElementById("start-quiz").addEventListener("click", lancerQuiz);
  document.getElementById("infos-plantes").addEventListener("click", afficherInfosPlantes);
}

// 🔹 Ajouter une plante
function ajouterPlanteAuto() {
  const val = document.getElementById("select-espece").value;
  if (!val) return;
  const [genre, espece] = val.split("|");
  const plante = plantes.find(p => p.genre === genre && p.espece === espece);
  if (!selectedPlantes.some(sp => sp.genre === genre && sp.espece === espece)) selectedPlantes.push(plante);
  afficherSelection();
}

// 🔹 Afficher la sélection
function afficherSelection() {
  const liste = document.getElementById("selection-liste");
  liste.innerHTML = "";
  selectedPlantes.forEach((p, i) => {
    const li = document.createElement("li");
    li.innerHTML = `${p.genre} <em>${p.espece}</em> <button data-i="${i}">❌</button>`;
    li.querySelector("button").onclick = e => {
      selectedPlantes.splice(e.target.dataset.i, 1);
      afficherSelection();
    };
    liste.appendChild(li);
  });

  const nbInput = document.getElementById("nb-questions");
  if (selectedPlantes.length > 0) {
    nbInput.max = selectedPlantes.length;
    if (parseInt(nbInput.value) > selectedPlantes.length) {
      nbInput.value = selectedPlantes.length;
    }
  }
}

// 🔹 Lancer le quiz
function lancerQuiz() {
  if (selectedPlantes.length < 3) return alert("Ajoute au moins 3 plantes 🌿");

  const nbQuestions = Math.min(parseInt(document.getElementById("nb-questions").value), selectedPlantes.length);
  const type = document.getElementById("quiz-type").value;

  const melange = selectedPlantes.sort(() => Math.random() - 0.5);
  questions = melange.slice(0, nbQuestions).map(q => {
    const autres = selectedPlantes.filter(p => p !== q).sort(() => Math.random() - 0.5).slice(0, 2);
    return { correcte: q, options: [q, ...autres].sort(() => Math.random() - 0.5) };
  });

  indexQuestion = 0;
  score = 0;
  erreurs = [];

  document.getElementById("liste-section").classList.add("hidden");
  document.getElementById("quiz-section").classList.remove("hidden");

  afficherQuestion(type);
}

// 🔹 Barre de progression
function majProgression() {
  const barre = document.getElementById("progress-bar");
  const avancement = ((indexQuestion) / questions.length) * 100;
  barre.style.width = `${avancement}%`;
}

// 🔹 Afficher une question
function afficherQuestion(type) {
  const quiz = document.getElementById("quiz-section");
  if (indexQuestion >= questions.length) return afficherResultats();

  majProgression();
  const q = questions[indexQuestion];
  let contenu = `<h2>Question ${indexQuestion + 1}/${questions.length}</h2>`;

  if (type == 1) {
    contenu += `<img src="${q.correcte.image}">
      <div id="options">${q.options.map(o => `<button class="option">${o.genre} ${o.espece}</button>`).join("")}</div>`;
  } else if (type == 2) {
    contenu += `<h3>${q.correcte.genre} ${q.correcte.espece}</h3>
      <div id="options">${q.options.map(o => `<img src="${o.image}" class="option-img" data-nom="${o.genre} ${o.espece}">`).join("")}</div>`;
  } else {
    contenu += `<img src="${q.correcte.image}">
      <input type="text" id="reponse" placeholder="Écris le nom complet">
      <button id="valider">Valider</button>
      <button id="indice">Indice 🍃</button>
      <div id="indice-texte"></div>`;
  }

  quiz.innerHTML = document.getElementById("progress-bar-container").outerHTML + contenu;

  if (type == 1 || type == 2) {
    document.querySelectorAll(".option, .option-img").forEach(b => {
      b.addEventListener("click", () => {
        const choix = b.innerText || b.dataset.nom;
        if (choix === `${q.correcte.genre} ${q.correcte.espece}`) score++;
        else erreurs.push({ question: q.correcte, reponse: choix });
        indexQuestion++;
        afficherQuestion(type);
      });
    });
  } else {
    document.getElementById("indice").onclick = () => {
      document.getElementById("indice-texte").innerText = `${q.correcte.genre} ${"_ ".repeat(q.correcte.espece.length)}`;
    };
    document.getElementById("valider").onclick = () => {
      const saisie = document.getElementById("reponse").value.trim().toLowerCase();
      const reponse = `${q.correcte.genre.toLowerCase()} ${q.correcte.espece.toLowerCase()}`;
      const diff = distanceLevenshtein(saisie, reponse);

      if (diff === 0) {
        score++;
      } else if (diff <= 2) {
        score += 0.5;
        erreurs.push({ question: q.correcte, reponse: saisie, faute: true });
      } else {
        erreurs.push({ question: q.correcte, reponse: saisie, faute: false });
      }

      indexQuestion++;
      afficherQuestion(type);
    };
  }
}

// 🔹 Afficher les résultats
function afficherResultats() {
  const quiz = document.getElementById("quiz-section");
  const resultats = document.getElementById("resultats-section");
  quiz.classList.add("hidden");
  resultats.classList.remove("hidden");

  let erreursHTML = "";
  if (erreurs.length) {
    erreursHTML = `<div class="resultat-erreurs">
      <h3>❌ Erreurs :</h3>
      ${erreurs.map(e => `
        <p>
          <strong>${e.reponse || "(aucune réponse)"} :</strong> 
          → ${e.question.genre} ${e.question.espece}
          ${e.faute ? "<em>(faute d’orthographe)</em>" : ""}
        </p>`).join("")}
    </div>`;
  } else {
    erreursHTML = "<p>Aucune erreur 🌿 Bravo !</p>";
  }

  resultats.innerHTML = `
    <h2>Résultats 🌸</h2>
    <p>Score : <strong>${score.toFixed(1)} / ${questions.length}</strong></p>
    ${erreursHTML}
    <button id="retour">↩️ Retour</button>`;

  document.getElementById("retour").onclick = () => {
    resultats.classList.add("hidden");
    document.getElementById("liste-section").classList.remove("hidden");
  };
}

// 🔹 Distance de Levenshtein
function distanceLevenshtein(a, b) {
  const matrix = Array.from({ length: a.length + 1 }, () => Array(b.length + 1).fill(0));
  for (let i = 0; i <= a.length; i++) matrix[i][0] = i;
  for (let j = 0; j <= b.length; j++) matrix[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      matrix[i][j] = Math.min(matrix[i - 1][j] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j - 1] + cost);
    }
  }
  return matrix[a.length][b.length];
}

// 🔹 Page "Infos Plantes"
async function afficherInfosPlantes() {
  try {
    const res = await fetch("./data/infosPlantes.txt");
    if (!res.ok) throw new Error("Fichier infosPlantes.txt introuvable");
    const texte = await res.text();
    const lignes = texte.split("\n").map(l => l.trim()).filter(Boolean);

    const contenu = document.getElementById("contenu-infos");
    contenu.innerHTML = "";
    let bloc = null;

    lignes.forEach(ligne => {
      if (ligne.endsWith(":")) {
        const genre = ligne.replace(":", "");
        bloc = document.createElement("div");
        bloc.className = "genre-info";
        bloc.dataset.genre = genre.toLowerCase();
        bloc.innerHTML = `<h3>${genre}</h3>`;
        contenu.appendChild(bloc);
      } else if (ligne.startsWith("-")) {
        const espece = document.createElement("div");
        espece.className = "espece-info";
        espece.dataset.espece = ligne.replace("-", "").trim().toLowerCase();
        espece.textContent = ligne.replace("-", "").trim();
        bloc.appendChild(espece);
      } else if (bloc) {
        const p = document.createElement("p");
        p.textContent = ligne;
        bloc.appendChild(p);
      }
    });

    document.getElementById("liste-section").classList.add("hidden");
    document.getElementById("infos-section").classList.remove("hidden");

    const recherche = document.getElementById("recherche-infos");
    recherche.value = "";
    recherche.oninput = () => {
      const filtre = recherche.value.toLowerCase();
      const genres = contenu.querySelectorAll(".genre-info");
      genres.forEach(g => {
        const texte = g.textContent.toLowerCase();
        g.style.display = texte.includes(filtre) ? "block" : "none";
      });
    };

    document.getElementById("retour-infos").onclick = () => {
      document.getElementById("infos-section").classList.add("hidden");
      document.getElementById("liste-section").classList.remove("hidden");
    };
  } catch (err) {
    alert("❌ Erreur : " + err.message);
  }
}

// 🔹 Démarrage
chargerPlantes();

