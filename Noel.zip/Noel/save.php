<?php
session_start();
if (!($_SESSION['logged'] ?? false)) exit;
$path = __DIR__ . '/data/gifts.json';
$gifts = json_decode(file_get_contents($path), true);
$gifts[] = [
'name' => $_POST['name'],
'description' => $_POST['description'],
'url' => $_POST['url']
];
file_put_contents($path, json_encode($gifts, JSON_PRETTY_PRINT));
echo "OK";