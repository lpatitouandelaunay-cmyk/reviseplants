// Ajout
document.getElementById("addForm").addEventListener("submit", async (e) => {
e.preventDefault();
const data = new FormData(e.target);
const r = await fetch("save.php", { method: "POST", body: data });
if (r.ok) location.reload();
});


// Suppression
document.querySelectorAll('.delete-btn').forEach(btn => {
btn.addEventListener('click', async () => {
const id = btn.dataset.id;
const r = await fetch('delete.php', {
method: 'POST',
headers: {'Content-Type': 'application/x-www-form-urlencoded'},
body: 'id=' + id
});
if (r.ok) location.reload();
});
});