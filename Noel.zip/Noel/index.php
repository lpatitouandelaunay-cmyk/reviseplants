<?php
$gifts = json_decode(file_get_contents(__DIR__ . '/data/gifts.json'), true);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>🎅 Ma Liste de Noël</title>
<link rel="stylesheet" href="assets/css/style.css">
<script defer src="assets/js/public.js"></script>
</head>
<body>
<h1>🎄 Ma Liste de Noël</h1>
<div id="gift-list">
<?php foreach ($gifts as $g): ?>
<div class="card">
<h2><?= htmlspecialchars($g['name']) ?></h2>
<p><?= nl2br(htmlspecialchars($g['description'])) ?></p>
<?php if (!empty($g['url'])): ?>
<a href="<?= htmlspecialchars($g['url']) ?>" target="_blank">🔗 Voir</a>
<?php endif; ?>
</div>
<?php endforeach; ?>
</div>
</body>
</html>